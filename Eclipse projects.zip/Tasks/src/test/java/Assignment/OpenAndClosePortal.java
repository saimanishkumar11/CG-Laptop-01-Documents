package Assignment;

import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;

import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class OpenAndClosePortal {
	ChromeDriver driver;
 
  @BeforeClass
  public void invokeBrowser()  {
	  System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");

		driver= new ChromeDriver();

		driver.manage().window().maximize();
		
		driver.get("https://www.capgemini.com/in-en/");
  }
  
  @Test(priority=0)
	public void verifyTitleOfThePage() {

		String expectedTitle="Capgemini - Get The Future You Want";
		String actualTitle;

		actualTitle= driver.getTitle();

		assertEquals(expectedTitle, actualTitle);

	}

  @AfterClass
  public void closeBrowser() {
		driver.quit();

	}

}
