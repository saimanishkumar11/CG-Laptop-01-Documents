package CapgeminiPortal;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class FunctionalityStepDef {
	//set up method
	WebDriver driver = null;
	@Before public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	//search functionality
	
	  @Given("^I navigates to \"([^\"]*)\"$")
	  public void I_navigates_to_CapgeminiPortal(String arg1) {
		     driver.navigate().to("https://www.capgemini.com/");
		     driver.manage().window().maximize();
	         System.out.println("user is in home page");
	         driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	     	 driver.findElement(By.id("macs_cookies_accept_necessary")).click();
	                
	  }
	  
	  @Then("I clicks on search")
	  public void I_clicks_on_search() {
		  driver.findElement(By.xpath("//button[@class='header-search-button header-search-open']")).click();
	  }
	  
	  @And("^I search for (.*)$")
	  public void I_search_for_value(String value) {
		  driver.findElement(By.id("keyword")).sendKeys(value);
		  driver.findElement(By.xpath("//button[@class='search-button common-top-search-button']")).click();
		  assertTrue(driver.getTitle().contains(value.toString()));
		  
	  }
	  
	  //contact us
	  @And("I click on contact us")
	  public void I_click_on_contact_us() {
		  driver.findElement(By.xpath("//div[@class='header-top']//ul//li[1]")).click();
		  String expectedTitle= "Contact Us | Capgemini";
		  String actualTitle= driver.getTitle();
		  assertEquals(expectedTitle, actualTitle);
	  }
	  
	  //cookies setting
	  @When("I click on Cookie settings")
	  public void I_click_on_Cookie_settings() throws InterruptedException {
		    JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,5000)");
			Thread.sleep(3000);
			driver.findElement(By.linkText("Cookie settings")).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
	  }
	  
	  @Then("I check the box")
	  public void I_check_the_box() throws InterruptedException  {
		  JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,200)");
			Thread.sleep(3000);
		  driver.findElement(By.id("accept_cookie_functional")).click();
		  driver.findElement(By.id("accept_cookie_statistics")).click();
		  driver.findElement(By.id("accept_cookie_targeting")).click();
		
	  }
		@And("I click on save my settings")
		public void I_click_on_save_my_settings() throws InterruptedException {
			  JavascriptExecutor js = (JavascriptExecutor)driver;
				js.executeScript("window.scrollBy(0,400)");
				Thread.sleep(3000);
			   driver.findElement(By.xpath("//a[@class='section__button more2']")).click();
			
		}
		  
		//career
		
		@When("I click on careers")
		public void I_click_on_careers() {
			driver.findElement(By.linkText("Careers")).click();
		}
		
		@Then("^I find for the (.*)$")
		 public void I_search_for_the_value(String input) {
			driver.findElement(By.name("keyword")).sendKeys(input);
			driver.findElement(By.xpath("//button[@class='form-search-button search-button archive-search-button']")).click();			
		}
		
		@And("I validate the result")
		public void I_validate_the_result() throws InterruptedException {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,100)");
			Thread.sleep(3000);
			String result= driver.findElement(By.xpath("//div[@class='table-td table-title']")).getText();
			if(result.contains("Automation Engineer")) {
				Assert.assertTrue(true);
				System.out.println("Test case passed");
			}
			else
				Assert.assertTrue(false);
			
					
		}
	  
	  //teardown
	  
	  @After public void closeBrowser() {
	 	  driver.close();
	  }

}
