package CapgeminiPortal;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

    @RunWith(Cucumber.class)             
	@CucumberOptions(features="src/test/resources/Features/Capgemni.feature",
	glue= {"CapgeminiPortal"},
	tags= "@career",
	monochrome = true,
	plugin={"html:target/cucumber/capgeminiportal.html"}

	)
	
	public class FunctionalityRunner {
}
