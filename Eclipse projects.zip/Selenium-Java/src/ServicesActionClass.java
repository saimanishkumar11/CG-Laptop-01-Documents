import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ServicesActionClass {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.capgemini.com/");
		Services(driver);
		
	}
	
	public static void Services(WebDriver driver) throws InterruptedException {
		driver.manage().window().maximize();
		driver.findElement(By.id("macs_cookies_accept_necessary")).click();
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(By.linkText("Services"))).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Cloud")).click();
	
	}

}
