import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelIntroduction {

	public static void main(String[] args) {

		//Invoking Browser
		//Chrome-ChromeDriver->Method 
		//Method name will be same for all the browser
		// WebDriver implement methods or own class methods
		//chromedeiver.exe->Chrome browser
		
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		//webdriver.chrome.driver-->key 
		//C:\\Manish\\chromedriver_win32\\chromedriver.exe-->value

		WebDriver driver= new ChromeDriver();
		
		//naviagte to application
		
		driver.get("https://rahulshettyacademy.com");
		
		//fetch and print title of the page in console
		
		System.out.println(driver.getTitle());
		
		//fetch and print url 
		
		System.out.println(driver.getCurrentUrl());
		
		//close the current window
		
		driver.close();

	}

}
