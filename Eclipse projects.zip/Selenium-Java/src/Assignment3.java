import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assignment3 {

	public static void main(String[] args)   {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
		
		driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		String uname= getUsername(driver);
		driver.findElement(By.name("username")).sendKeys(uname);
		StringBuffer reqPwd= getPassword(driver);
		driver.findElement(By.name("password")).sendKeys(reqPwd);
		driver.findElement(By.xpath("//input[@value='user']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[id='okayBtn']")));
		driver.findElement(By.cssSelector("button[id='okayBtn']")).click();
		drpDown(driver);
		driver.findElement(By.name("terms")).click();
		driver.findElement(By.id("signInBtn")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn btn-info']")));
		addToCart(driver);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='nav-link btn btn-pr")));
		driver.findElement(By.xpath("//a[contains(text(),'Checkout')]")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-success']")).click();
	}
	
	public static String getUsername(WebDriver driver) {
		String msg= driver.findElement(By.xpath("//p[@class='text-center text-white']")).getText();
		//username is rahulshettyacademy and Password is learning
		//0        1       2              3      4     5    6
		String[] splitmsg= msg.split(" ");
		String uname= splitmsg[2];		
		return uname;		
	}
	
	public static StringBuffer getPassword(WebDriver driver) {
		String msg= driver.findElement(By.xpath("//p[@class='text-center text-white']")).getText();
		//(username is rahulshettyacademy and Password is learning)
		//0        1       2              3      4     5    6
		String[] splitmsg= msg.split(" ");
		String pwd= splitmsg[6];
		//creating a constructor of StringBuffer class  to remove last char from String
		StringBuffer sb= new StringBuffer(pwd); 
		//invoking the method  
		StringBuffer reqPwd = sb.deleteCharAt(sb.length()-1);  
		return reqPwd;		
	}
	
	public static void drpDown(WebDriver driver) {
		WebElement drpDown= driver.findElement(By.tagName("select"));
		Select drp= new Select(drpDown);
		drp.selectByIndex(2);
	
	}
	
	public static void addToCart(WebDriver driver) {
		List<WebElement> items = driver.findElements(By.xpath("//button[@class='btn btn-info']"));
		for(WebElement cartButton:items) {
			cartButton.click();
		}
	
		
		
	}

}
