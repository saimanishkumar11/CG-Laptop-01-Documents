import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCart {
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//implicit wait
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		//Explicit wait
		//create object for WebDriverWait class
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(5));

		// delcare array with the list of vegetables to be add to cart
		String[] itemsNeeded = { "Cucumber", "Brocolli", "Beetroot" };

		driver.get("https://rahulshettyacademy.com/seleniumPractise/");
		
		AddToCart a = new AddToCart();
		a.addItems(driver, itemsNeeded);
		
		driver.findElement(By.cssSelector("img[alt='Cart']")).click();
		driver.findElement(By.xpath("//button[text()='PROCEED TO CHECKOUT']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input.promoCode")));
		driver.findElement(By.cssSelector("input.promoCode")).sendKeys("rahulshettyacademy");
		driver.findElement(By.className("promoBtn")).click();
		//Explicit wait
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='promoInfo']")));   
		
		System.out.println(driver.findElement(By.xpath("//span[@class='promoInfo']")).getText());
		assertEquals(driver.findElement(By.xpath("//span[@class='promoInfo']")).getText(),"Code applied ..!");

	}

	public void addItems(WebDriver driver, String[] itemsNeeded) {

		int j = 0;
		// find elements will return the list of Webelements
		List<WebElement> products = driver.findElements(By.cssSelector("h4[class='product-name']"));

		// use sise() to get the size of the list
		for (int i = 0; i < products.size(); i++) {
			// check whether name you extracted is present in array or not
			// convert array into arraylist for easy search
			List itemsNeededList = Arrays.asList(itemsNeeded);

			// get the name of the product & format it to get only vegetable name
			String[] name = products.get(i).getText().split("-");
			// name[0]=Brocolli
			// name[1]=1 Kg
			// since there is a space after vegetable name Brocolli - 1 kg use trim() to
			// remove the space
			String formattedName = name[0].trim();

			if (itemsNeededList.contains(formattedName)) {
				j++;
				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();

				if (j == itemsNeeded.length)
					break;

			}

		}
	}

}
