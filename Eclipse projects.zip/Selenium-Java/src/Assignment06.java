import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment06 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		WebElement option2 = driver.findElement(By.id("checkBoxOption2"));
		String checkboxText = driver.findElement(By.xpath("//label[@for='benz']")).getText();
		option2.click();
		if(option2.isSelected()) {		
			System.out.println(checkboxText);
		}
		else {
			System.out.println("Option2 is not selected");
		}
		WebElement optionDropdown= driver.findElement(By.id("dropdown-class-example"));
		Select dropdown= new Select(optionDropdown);
		dropdown.selectByVisibleText(checkboxText);
		
		driver.findElement(By.id("name")).sendKeys(checkboxText);
		driver.findElement(By.id("confirmbtn")).click();
		Thread.sleep(3000);	
		String alertText= driver.switchTo().alert().getText();
		
		if(alertText.contains(checkboxText)) {
			 assertTrue(true);
		}
		else {
			assertTrue(false);
		}

	}

}
