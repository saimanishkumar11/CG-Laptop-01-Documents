import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AssignmentDropdown {

	public static void main(String[] args) throws InterruptedException {
		//launching chrome browser
		System.setProperty("webdriver.chrome.driver", "C:\\\\Manish\\\\chromedriver_win32\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//navigte to the application
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		//check the first checkbox
		driver.findElement(By.id("checkBoxOption1")).click();
		
		Thread.sleep(2000);
		
		//verify the first checkbox whether it is sucessfully checked
	    assertTrue(driver.findElement(By.id("checkBoxOption1")).isSelected());
	    
	    Thread.sleep(2000);
	    
	    //uncheck the first checkbox
	    driver.findElement(By.id("checkBoxOption1")).click();
	    
	    Thread.sleep(2000);
	    
	  //verify the first checkbox whether it is sucessfully unchecked
	    assertFalse(driver.findElement(By.id("checkBoxOption1")).isSelected());
	    
	    driver.close();
	    
	}

}
