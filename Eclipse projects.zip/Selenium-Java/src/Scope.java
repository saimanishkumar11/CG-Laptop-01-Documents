import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scope {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		//1) To get the count of links 
		System.out.println(driver.findElements(By.tagName("a")).size());
		
		//limiting webdriver scope to footer section
		WebElement footerDriver = driver.findElement(By.id("gf-BIG"));
		
		//2) get the count of links in footer section 
		System.out.println(footerDriver.findElements(By.tagName("a")).size());
		
		//3) get the count of links in first column of the footer section
		//1. limit the webdriver scope to first column of footer section 
		WebElement footerCol1 = footerDriver.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
		System.out.println(footerCol1.findElements(By.tagName("a")).size());
		
		//4) click on each link in the first column of footer section
		List<WebElement>linksOnCol1 = footerCol1.findElements(By.tagName("a"));
		for(int i=1; i<linksOnCol1.size();i++) {
			String clicOnLink= Keys.chord(Keys.CONTROL,Keys.ENTER); //all pages will be opened in new page if we
			//press control and click on the link
			linksOnCol1.get(i).sendKeys(clicOnLink);
			Thread.sleep(5000);
		}
		
		Set<String>linkWindow =driver.getWindowHandles();
		Iterator<String> it=linkWindow.iterator();
		while(it.hasNext()) {
			driver.switchTo().window(it.next());
			System.out.println(driver.getTitle());
		}
		

	}

}
