import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment07WebTable {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Manish\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver =new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,600)");
		
		int rows= driver.findElements(By.cssSelector(".table-display tr")).size();		
		System.out.println("the no. of rows are "+rows);
		
		int columns =driver.findElements(By.cssSelector(".table-display th")).size();
		System.out.println("the no. of columns are "+columns);
		
		String secondRow= driver.findElement(By.cssSelector(".table-display tr:nth-child(3)")).getText();
		System.out.println(secondRow);
		

	}

}
