package features;

import com.intuit.karate.junit5.Karate;

public class TestRunner {
	
	@Karate.Test
	Karate capgeminiPortal() {
		return Karate.run("search").relativeTo(getClass());
		
	}
	

	

}
