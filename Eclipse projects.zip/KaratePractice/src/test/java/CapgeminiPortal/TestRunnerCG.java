package CapgeminiPortal;

import com.intuit.karate.junit5.Karate;

public class TestRunnerCG {
	
	@Karate.Test
	Karate searchFunctionality() {
		return Karate.run("search").relativeTo(getClass());
		
	}
	
	@Karate.Test
	Karate contactUsFunctionality() {
		return Karate.run("contactUs").relativeTo(getClass());
		
	}
	
	@Karate.Test
	Karate cookiesFunctionality() {
		return Karate.run("Cookies").relativeTo(getClass());
		
	}

}
